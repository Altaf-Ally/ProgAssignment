/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package question2library;
import java.util.Scanner;
/**
 *
 * @author altaafally
 */
public class Question2Library {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         LibraryManagementSystem library = new LibraryManagementSystem();
        library.addItem(new Book("The Great Gatsby", 1001, "F. Scott Fitzgerald"));
        library.addItem(new DVD("Inception", 2001, "Christopher Nolan"));
        library.addItem(new Book("To Kill a Mockingbird", 1002, "Harper Lee"));

        library.displayLibraryItems();
    }
}
    
    

