/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question2library;

/**
 *
 * @author altaafally
 */
public class Book extends Item {
     private String author;

    public Book(String title, int itemId, String author) {
        super(title, itemId);
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public String toString() {
        return "Book - Title: " + getTitle() + ", Author: " + getAuthor() + ", ID: " + getItemId();
    }

}
