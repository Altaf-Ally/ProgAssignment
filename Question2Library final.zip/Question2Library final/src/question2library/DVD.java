/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question2library;

/**
 *
 * @author altaafally
 */
public class DVD extends Item {
    private String director;

    public DVD(String title, int itemId, String director) {
        super(title, itemId);
        this.director = director;
    }

    public String getDirector() {
        return director;
    }

    public String toString() {
        return "DVD - Title: " + getTitle() + ", Director: " + getDirector() + ", ID: " + getItemId();
    }
   

}
