/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question2library;

/**
 *
 * @author altaafally
 */
public class LibraryManagementSystem {
     private static final int MAX_ITEMS = 100;
    private Item[] libraryItems;
    private int itemCount;

    public LibraryManagementSystem() {
        libraryItems = new Item[MAX_ITEMS];
        itemCount = 0;
    }

    public void addItem(Item item) {
        if (itemCount < MAX_ITEMS) {
            libraryItems[itemCount] = item;
            itemCount++;
        } else {
            System.out.println("Library is full. Cannot add more items.");
        }
    }

    public void displayLibraryItems() {
        System.out.println("Library Items:");
        for (int i = 0; i < itemCount; i++) {
            System.out.println(libraryItems[i].toString());
        }
    }

}
