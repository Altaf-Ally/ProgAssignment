/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question2library;

/**
 *
 * @author altaafally
 */
public class Item {
      private String title;
    private int itemId;

    public Item(String title, int itemId) {
        this.title = title;
        this.itemId = itemId;
    }

    public String getTitle() {
        return title;
    }

    public int getItemId() {
        return itemId;
    }

}
