/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import question2library.Book;
import question2library.DVD;

/**
 *
 * @author altaafally
 */
public class LibraryManagementSystem {

    private static int MAX_ITEMS;
    
    public LibraryManagementSystem() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testAddItem() {
        LibraryManagementSystem library = new LibraryManagementSystem();
        Book book = new Book("Test Book", 1003, "Test Author");
        library.addItem(book);

        assertEquals(1, library.getItemCount());
    }

    @Test
    public void testDisplayLibraryItems() {
        LibraryManagementSystem library = new LibraryManagementSystem();
        Book book = new Book("Test Book", 1004, "Test Author");
        library.addItem(book);

        // Redirect standard output to capture printed output
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        library.displayLibraryItems();

        String expectedOutput = "Library Items:\nBook - Title: Test Book, Author: Test Author, ID: 1004\n";
        assertEquals(expectedOutput, outContent.toString());
    }
          @Test
    public void testAddItemMaxCapacityReached() {
        LibraryManagementSystem library = new LibraryManagementSystem();
        for (int i = 0; i < LibraryManagementSystem.MAX_ITEMS; i++) {
            library.addItem(new Book("Book " + i, 1000 + i, "Author " + i));
        }

        Book extraBook = new Book("Extra Book", 2000, "Extra Author");
        library.addItem(extraBook);

        assertEquals(LibraryManagementSystem.MAX_ITEMS, library.getItemCount());
        // Ensure the last item added is the extra book
        assertEquals(extraBook, library.getItems()[LibraryManagementSystem.MAX_ITEMS - 1]);
    }

    @Test
    public void testBookToString() {
         Book book = new Book("Test Book", 1005, "Test Author");
        assertEquals("Book - Title: Test Book, Author: Test Author, ID: 1005", book.toString());
    }

    @Test
    public void testDVDToString() {
        DVD dvd = new DVD("Test DVD", 2005, "Test Director");
        assertEquals("DVD - Title: Test DVD, Director: Test Director, ID: 2005", dvd.toString());
    }

    private int getItemCount() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private Object[] getItems() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void addItem(Book extraBook) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void displayLibraryItems() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    
 
    



