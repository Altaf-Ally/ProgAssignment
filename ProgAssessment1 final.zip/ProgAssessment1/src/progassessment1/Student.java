/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progassessment1;
import javax.swing.JOptionPane;
import java.util.ArrayList;

/**
 *
 * @author altaafally
 */
public class Student {
    
    private String studentName;
    private int studentAge;
    private int studentID;
    private String studentEmail;
    private String studentCourse;

    public Student(int id, String name, int age, String email, String course)
    {
        studentID = id;
        studentName = name;
        studentAge = age;
        studentEmail = email;
        studentCourse = course;
    }

    // Getters
    public int getStudentID()
    {
        return studentID;
    }

    public String getStudentName()
    {
        return studentName;
    }

    public int getStudentAge()
    {
        return studentAge;
    }

    public String getStudentEmail()
    {
        return studentEmail;
    }

    public String getStudentCourse()
    {
        return studentCourse;
    }

    // Capture a new student
    public void SaveStudent(int idCounter)
    {
        int id;
        while (true)
        {
            try
            {
                id = Integer.parseInt(JOptionPane.showInputDialog("Enter the student id:"));
                break;
            } catch (NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Invalid input for student ID. Please enter a number.");
            }
        }

        studentID = id;
        studentName = JOptionPane.showInputDialog("Enter the student name:");
       
        int age;
        while (true)
        {
            try
            {
                age = Integer.parseInt(JOptionPane.showInputDialog("Enter the student age:"));
                if (age >= 16)
                {
                    break;
                } else
                {
                    JOptionPane.showMessageDialog(null, "Invalid age. Age must be 16 or older.");
                }
            } catch (NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid age.");
            }
        }

        studentAge = age;
        studentEmail = JOptionPane.showInputDialog("Enter the student email:");
        studentCourse = JOptionPane.showInputDialog("Enter the student course:");

        JOptionPane.showMessageDialog(null, "Student details saved successfully.");
    }

    // Search for a student
    public Student searchStudent(ArrayList<Student> students, int searchID)
    {
        for (Student student : students)
        {
            if (student.getStudentID() == searchID)
            {
                return student;
            }
        }
        return null;
    }

    // Delete a student
    public void deleteStudent(ArrayList<Student> students, int deleteID) {
        Student studentToDelete = null;
        for (Student student : students) {
            if (student.getStudentID() == deleteID) {
                studentToDelete = student;
                break;
            }
        }

        if (studentToDelete != null) {
            // Ask for confirmation before deleting
            String confirmationMessage = "Are you sure you want to delete student " + studentToDelete.getStudentName() + " (ID: " + deleteID + ")?\n" +
                    "Type 'yes' (y) to delete or any other key to go back.";

            String userInput = JOptionPane.showInputDialog(confirmationMessage).toLowerCase();
            if ("yes".equals(userInput) || "y".equals(userInput)) {
                students.remove(studentToDelete);
                JOptionPane.showMessageDialog(null, "Student with Student ID: " + deleteID + " was deleted!");
            } else {
                JOptionPane.showMessageDialog(null, "Deletion canceled.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Student with Student ID: " + deleteID + " was not found!");
        }
    }

    // View student report
    public String viewStudentReport(ArrayList<Student> students)
    {
        StringBuilder report = new StringBuilder("STUDENT REPORT\n");

        for (Student student : students)
        {
            report.append("STUDENT ID: ").append(student.getStudentID()).append("\n")
                    .append("STUDENT NAME: ").append(student.getStudentName()).append("\n")
                    .append("STUDENT AGE: ").append(student.getStudentAge()).append("\n")
                    .append("STUDENT EMAIL: ").append(student.getStudentEmail()).append("\n")
                    .append("STUDENT COURSE: ").append(student.getStudentCourse()).append("\n")
                    .append("-----------------------\n");
        }

        return report.toString();
    }
    }


