/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import progassessment1.Student;

/**
 *
 * @author altaafally
 */
public class studentTest {
    
    public studentTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

  

    @Test
    public void testSearchStudent() {
        // Create some students
        Student student1 = new Student(1, "Alice", 20, "alice@example.com", "Computer Science");
        Student student2 = new Student(2, "Bob", 18, "bob@example.com", "Mathematics");
        Student student3 = new Student(3, "Charlie", 22, "charlie@example.com", "Physics");

        ArrayList<Student> students = new ArrayList<>();
        students.add(student1);
        students.add(student2);
        students.add(student3);

        // Search for a student
        Student foundStudent = student1.searchStudent(students, 1);
        assertEquals(student1, foundStudent);

        // Search for a non-existing student
        foundStudent = student1.searchStudent(students, 5);
        assertNull(foundStudent);
    }

    @Test
    public void testDeleteStudent() {
        // Create some students
        Student student1 = new Student(1, "Alice", 20, "alice@example.com", "Computer Science");
        Student student2 = new Student(2, "Bob", 18, "bob@example.com", "Mathematics");
        Student student3 = new Student(3, "Charlie", 22, "charlie@example.com", "Physics");

        ArrayList<Student> students = new ArrayList<>();
        students.add(student1);
        students.add(student2);
        students.add(student3);

        // Delete an existing student
        student1.deleteStudent(students, 1);
        assertEquals(2, students.size());

        // Try to delete a non-existing student
        student1.deleteStudent(students, 5);
        assertEquals(2, students.size());
    }

}


